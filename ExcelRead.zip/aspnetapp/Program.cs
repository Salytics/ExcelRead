using System;
using System.IO;

class ArrayExample
{
    static void Main()
    {
        string pathnew = "C:/Users/dhrud/Documents/aspnetapp/csv/CSVnew.csv";

        System.IO.File.WriteAllText(pathnew,string.Empty);

        string path = "C:/Users/dhrud/Documents/aspnetapp/csv/CSVallRecord.csv";
        string[] lines = System.IO.File.ReadAllLines(path);
        foreach(string line in lines)
        {
            String fileRow = "";

            string[] csvRecordData = line.Split(',');
            if(csvRecordData[6] == ""){
                csvRecordData[6] = "Global";
            }
            if(csvRecordData[7] == ""){
                csvRecordData[7] = "Multiple";
            }
            if(csvRecordData[8] == ""){
                csvRecordData[8] = "Multiple Programs";
            }
            if(csvRecordData[9] == ""){
                csvRecordData[9] = "Confirmation";
            }
            if(csvRecordData[10] == ""){
                csvRecordData[10] = "TOFU";
            }
            if(csvRecordData[11] == ""){
                csvRecordData[11] = "Inbound";
            }
            if(csvRecordData[12] == ""){
                csvRecordData[12] = "Financial Services";
            }
            if(csvRecordData[13] == ""){
                csvRecordData[13] = "Tradeshow";
            }
            if(csvRecordData[14] == ""){
                csvRecordData[14] = "Virtual Event";
            }
            if(csvRecordData[15] == ""){
                csvRecordData[15] = "";
            }
            if(csvRecordData[16] == ""){
                csvRecordData[16] = "no";
            }
            if(csvRecordData[17] == ""){
                csvRecordData[17] = "None";
            }
            if(csvRecordData[18] == ""){
                csvRecordData[18] = "None";
            }
            if(csvRecordData[19] == ""){
                csvRecordData[19] = "None";
            }
            if(csvRecordData[20] == ""){
                csvRecordData[20] = "MDM - Customer 360";
            }
            if(csvRecordData[21] == ""){
                csvRecordData[21] = "MDM";
            }
            if(csvRecordData[22] == ""){
                csvRecordData[22] = "Whitney Icenhauer";
            }
            if(csvRecordData[23] == ""){
                csvRecordData[23] = "NoneRegion";
            }
            if(csvRecordData[24] == ""){
                csvRecordData[24] = "Master Data Mgmt - Single View - Data Hub";
            }
            if(csvRecordData[25] == ""){
                csvRecordData[25] = "Product Marketing";
            }
               fileRow = fileRow +','+ csvRecordData[0];
               fileRow = fileRow +','+ csvRecordData[1];
               fileRow = fileRow +','+ csvRecordData[2];
               fileRow = fileRow +','+ csvRecordData[3];
               fileRow = fileRow +','+ csvRecordData[4];
               fileRow = fileRow +','+ csvRecordData[5];
               fileRow = fileRow +','+ csvRecordData[6];
               fileRow = fileRow +','+ csvRecordData[7];
               fileRow = fileRow +','+ csvRecordData[8];
               fileRow = fileRow +','+ csvRecordData[9];
               fileRow = fileRow +','+ csvRecordData[10];
               fileRow = fileRow +','+ csvRecordData[11];
               fileRow = fileRow +','+ csvRecordData[12];
               fileRow = fileRow +','+ csvRecordData[13];
               fileRow = fileRow +','+ csvRecordData[14];
               fileRow = fileRow +','+ csvRecordData[15];
               fileRow = fileRow +','+ csvRecordData[16];
               fileRow = fileRow +','+ csvRecordData[17];
               fileRow = fileRow +','+ csvRecordData[18];
               fileRow = fileRow +','+ csvRecordData[19];
               fileRow = fileRow +','+ csvRecordData[20];
               fileRow = fileRow +','+ csvRecordData[21];
               fileRow = fileRow +','+ csvRecordData[22];
               fileRow = fileRow +','+ csvRecordData[23];
               fileRow = fileRow +','+ csvRecordData[24];
               fileRow = fileRow +','+ csvRecordData[25];
               
               fileRow = fileRow + '\n';
               fileRow = fileRow.Remove(0, 1);
                
                Console.WriteLine("Hello, " +fileRow);

            foreach (string column in csvRecordData) {
                // Do something

            }
            File.AppendAllText(pathnew, fileRow);

        }

    }
    static void SendMessage(string name, int msg)
    {
        Console.WriteLine("Hello, " + name + "! Count to " + msg);
    }
}